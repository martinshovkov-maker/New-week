package com.week.player;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
  // Keep the WebView alive when the app goes to background so music keeps playing.
  @Override
  public void onPause() {
    super.onPause();
    if (getBridge() != null && getBridge().getWebView() != null) {
      getBridge().getWebView().onResume();
      getBridge().getWebView().resumeTimers();
    }
  }
}
